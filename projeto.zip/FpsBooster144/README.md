# FPS Booster 144 (etapa 1)

App Android (Kotlin + Jetpack Compose) para o Redmi Note 13 Pro.

Etapa 1: detecção real de hardware, leitura dos modos de tela, monitoramento térmico/bateria/RAM,
biblioteca de jogos e os botões OTIMIZAR AGORA e FPS MÁXIMO.

## Compilar sem computador (GitHub Actions)
1. Crie uma conta e um repositório no github.com.
2. Add file > Upload files: envie `projeto.zip` e `build.yml`.
3. Abra `build.yml`, toque no lápis e, no nome do arquivo, troque por `.github/workflows/build.yml`. Salve (Commit).
4. Aba Actions > "Build APK". Aguarde terminar (uns 10 minutos).
5. Abra a execução concluída > Artifacts > baixe `FpsBooster144-debug-apk`, extraia o zip e instale o `app-debug.apk`.

## Compilar no computador
Android Studio (JDK 17): abra a pasta FpsBooster144 e rode `gradle assembleDebug`.
O APK fica em `app/build/outputs/apk/debug/`.
