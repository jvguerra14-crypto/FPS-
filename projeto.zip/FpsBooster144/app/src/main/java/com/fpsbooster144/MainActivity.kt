package com.fpsbooster144

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.fpsbooster144.core.display.RefreshMode
import com.fpsbooster144.ui.MainScreen
import com.fpsbooster144.ui.MainViewModel
import com.fpsbooster144.ui.theme.AppTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                MainScreen(
                    viewModel = viewModel,
                    onApplyMode = ::applyPreferredMode,
                    onLaunchGame = ::launchGame,
                    onOpenDisplaySettings = ::openDisplaySettings
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshGames()
    }

    /** Pede ao sistema o modo de tela para a janela deste app. O sistema decide se aceita. */
    private fun applyPreferredMode(mode: RefreshMode): Boolean = try {
        val attributes = window.attributes
        attributes.preferredDisplayModeId = mode.modeId
        window.attributes = attributes
        true
    } catch (t: Throwable) {
        false
    }

    private fun launchGame(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent == null) {
            Toast.makeText(this, "Não foi possível abrir este jogo.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(intent)
        } catch (t: Throwable) {
            Toast.makeText(this, "Não foi possível abrir este jogo.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openDisplaySettings() {
        try {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        } catch (t: Throwable) {
            Toast.makeText(this, "Abra Configurações > Tela manualmente.", Toast.LENGTH_SHORT).show()
        }
    }
}
