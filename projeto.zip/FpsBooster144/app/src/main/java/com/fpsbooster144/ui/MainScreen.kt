package com.fpsbooster144.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fpsbooster144.core.device.DeviceInfo
import com.fpsbooster144.core.display.DisplayStatus
import com.fpsbooster144.core.display.RefreshMode
import com.fpsbooster144.core.game.GameEntry
import com.fpsbooster144.core.optimize.ActionResult
import com.fpsbooster144.core.optimize.ActionStatus
import com.fpsbooster144.core.system.SystemSnapshot
import com.fpsbooster144.ui.theme.StatusColors
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun MainScreen(
    viewModel: MainViewModel,
    onApplyMode: (RefreshMode) -> Boolean,
    onLaunchGame: (String) -> Unit,
    onOpenDisplaySettings: () -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (state.loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item { Header(state.device) }
                item { RefreshHero(state.display) }
                item {
                    ActionButtons(
                        running = state.running,
                        onOptimize = { viewModel.optimize(false, onApplyMode) },
                        onMaxFps = { viewModel.optimize(true, onApplyMode) }
                    )
                }
                if (state.running || state.results.isNotEmpty()) {
                    item { ResultsCard(state.resultsTitle, state.running, state.results) }
                }
                item { MonitorCard(state.snapshot) }
                item { RecommendationsCard(state.display, state.snapshot, onOpenDisplaySettings) }
                item { SectionTitle("Jogos instalados") }
                if (state.games.isEmpty()) {
                    item {
                        Text(
                            "Nenhum jogo encontrado. Jogos instalados fora da Play Store podem não ser reconhecidos como jogo.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    items(state.games, key = { it.packageName }) { game ->
                        GameRow(game, onLaunchGame)
                    }
                }
                item { DeviceDetailsCard(state.device) }
            }
        }
    }
}

@Composable
private fun Header(device: DeviceInfo?) {
    if (device == null) return
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            device.marketingName ?: device.model,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            device.variant.label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "${device.chipName}, GPU ${device.gpuName}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun RefreshHero(display: DisplayStatus?) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                "Taxa de atualização da tela agora",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = display?.currentHz?.roundToInt()?.toString() ?: "--",
                    fontSize = 88.sp,
                    lineHeight = 88.sp,
                    fontWeight = FontWeight.Light
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "Hz",
                    fontSize = 24.sp,
                    modifier = Modifier.padding(bottom = 14.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (display != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    display.supportedRates.forEach { hz ->
                        RateChip(hz, selected = abs(hz - display.currentHz) < 1f)
                    }
                }
                Text(
                    "O painel vai até ${display.maxHz.roundToInt()} Hz. Isso é a tela, não o FPS do jogo.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun RateChip(hz: Float, selected: Boolean) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    ) {
        Text(
            "${hz.roundToInt()} Hz",
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun ActionButtons(running: Boolean, onOptimize: () -> Unit, onMaxFps: () -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(
            onClick = onOptimize,
            enabled = !running,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.weight(1f).height(54.dp)
        ) {
            Text("OTIMIZAR AGORA", fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
        }
        Button(
            onClick = onMaxFps,
            enabled = !running,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary
            ),
            modifier = Modifier.weight(1f).height(54.dp)
        ) {
            Text("FPS MÁXIMO", fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
        }
    }
}

@Composable
private fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = content
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 6.dp)
    )
}

@Composable
private fun ResultsCard(title: String, running: Boolean, results: List<ActionResult>) {
    Panel {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        if (running) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
        }
        results.forEach { result -> ResultRow(result) }
    }
}

@Composable
private fun ResultRow(result: ActionResult) {
    val color = statusColor(result.status)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            Modifier
                .padding(top = 6.dp)
                .size(10.dp)
                .background(color, CircleShape)
        )
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(result.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(result.status.label, style = MaterialTheme.typography.labelMedium, color = color)
            Text(
                result.detail,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun statusColor(status: ActionStatus): Color = when (status) {
    ActionStatus.APPLIED -> StatusColors.ok
    ActionStatus.INFO -> StatusColors.info
    ActionStatus.WARNING -> StatusColors.warn
    ActionStatus.NOT_ALLOWED -> StatusColors.bad
}

@Composable
private fun KeyValue(
    key: String,
    value: String,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            key,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            value,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.End,
            color = valueColor
        )
    }
}

private fun gb(mb: Long): String = String.format(Locale.getDefault(), "%.1f GB", mb / 1024f)

@Composable
private fun MonitorCard(snapshot: SystemSnapshot?) {
    Panel {
        Text("Monitoramento", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        if (snapshot == null) {
            Text("Lendo sensores...", style = MaterialTheme.typography.bodyMedium)
        } else {
            val thermalColor = when {
                snapshot.thermalLevel >= 3 -> StatusColors.bad
                snapshot.thermalLevel == 2 -> StatusColors.warn
                else -> StatusColors.ok
            }
            KeyValue("Estado térmico", snapshot.thermalLabel, thermalColor)
            KeyValue(
                "Margem térmica",
                snapshot.thermalHeadroom?.let { "${(it * 100).roundToInt()}% do limite" }
                    ?: "indisponível neste aparelho"
            )
            KeyValue(
                "Temperatura da bateria",
                snapshot.batteryTempC?.let { String.format(Locale.getDefault(), "%.1f °C", it) }
                    ?: "indisponível"
            )
            KeyValue(
                "Bateria",
                snapshot.batteryPercent?.let { "$it%" + if (snapshot.charging) " (carregando)" else "" }
                    ?: "indisponível"
            )
            KeyValue("RAM livre", "${gb(snapshot.ramAvailMb)} de ${gb(snapshot.ramTotalMb)}")
            KeyValue("Economia de bateria", if (snapshot.powerSave) "ativa" else "desativada")
            KeyValue("FPS dos jogos", "não medido nesta versão")
            Text(
                "A temperatura mostrada é a da bateria. O Android não informa a da CPU ou GPU para apps comuns.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun RecommendationsCard(
    display: DisplayStatus?,
    snapshot: SystemSnapshot?,
    onOpenDisplaySettings: () -> Unit
) {
    val tips = buildList {
        if (display != null && display.currentHz + 1f < display.maxHz) {
            add(
                "A tela está em ${display.currentHz.roundToInt()} Hz e o painel chega a " +
                    "${display.maxHz.roundToInt()} Hz. Em Configurações > Tela, escolha a taxa de atualização mais alta."
            )
        }
        if (snapshot?.powerSave == true) {
            add("Desative a economia de bateria antes de jogar: ela pode limitar desempenho e taxa de atualização.")
        }
        if ((snapshot?.thermalLevel ?: 0) >= 2) {
            add("O aparelho está aquecendo. Deixe esfriar e evite jogar carregando para manter os quadros estáveis.")
        }
        add("Dentro de cada jogo, escolha o maior limite de quadros que ele oferecer. Só o jogo define o FPS máximo permitido.")
    }
    Panel {
        Text(
            "Configurações recomendadas",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        tips.forEach { tip ->
            Text(tip, style = MaterialTheme.typography.bodyMedium)
        }
        OutlinedButton(onClick = onOpenDisplaySettings, shape = RoundedCornerShape(14.dp)) {
            Text("Abrir configurações de tela")
        }
    }
}

@Composable
private fun GameRow(game: GameEntry, onLaunch: (String) -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface
    ) {
        Row(
            modifier = Modifier.padding(start = 16.dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    game.label,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    game.packageName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            FilledTonalButton(onClick = { onLaunch(game.packageName) }) { Text("Abrir") }
        }
    }
}

@Composable
private fun DeviceDetailsCard(device: DeviceInfo?) {
    if (device == null) return
    Panel {
        Text("Dados do aparelho", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text(
            device.variantNote,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        KeyValue("Fabricante", device.manufacturer)
        KeyValue("Modelo (código)", device.model)
        KeyValue("Codinome", device.codename)
        KeyValue("Processador", device.chipName)
        KeyValue("SoC (fabricante)", device.socManufacturer ?: "indisponível")
        KeyValue("SoC (modelo)", device.socModel ?: "indisponível")
        KeyValue("Hardware / placa", "${device.hardware} / ${device.board}")
        KeyValue("GPU", device.gpuName)
        KeyValue("OpenGL ES", device.gpuVersion ?: "indisponível")
        KeyValue("RAM total", gb(device.ramTotalMb))
        KeyValue("Android", "${device.androidRelease} (API ${device.sdkInt})")
        KeyValue("Sistema", "${device.osName} ${device.osVersionRaw}")
        KeyValue("Build", device.buildDisplay)
        KeyValue("Patch de segurança", device.securityPatch ?: "indisponível")
        Text(
            "A versão do HyperOS vem de propriedades que a Xiaomi não documenta. Se aparecer vazia ou estranha, a build acima é a fonte confiável.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
