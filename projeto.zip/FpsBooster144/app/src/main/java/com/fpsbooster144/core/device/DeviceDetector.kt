package com.fpsbooster144.core.device

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.provider.Settings

enum class Variant(val label: String) {
    MEDIATEK_4G("Compatível com Redmi Note 13 Pro 4G (MediaTek)"),
    QUALCOMM_5G("Compatível com Redmi Note 13 Pro 5G (Snapdragon)"),
    UNKNOWN("Variante não identificada")
}

data class DeviceInfo(
    val manufacturer: String,
    val brand: String,
    val model: String,
    val codename: String,
    val marketingName: String?,
    val hardware: String,
    val board: String,
    val socManufacturer: String?,
    val socModel: String?,
    val chipName: String,
    val gpuName: String,
    val gpuVersion: String?,
    val variant: Variant,
    val variantNote: String,
    val ramTotalMb: Long,
    val androidRelease: String,
    val sdkInt: Int,
    val securityPatch: String?,
    val osName: String,
    val osVersionRaw: String,
    val buildDisplay: String
)

/** Detecta o hardware real do aparelho. Nada aqui é presumido: tudo vem do sistema. */
class DeviceDetector(private val context: Context) {

    fun detect(): DeviceInfo {
        val gpu = GpuReader.read()

        val socManufacturer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Build.SOC_MANUFACTURER.cleanOrNull()
        } else null
        val socModel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Build.SOC_MODEL.cleanOrNull()
        } else null

        val hardware = Build.HARDWARE.orEmpty()
        val socText = listOfNotNull(socManufacturer, socModel, hardware, Build.BOARD)
            .joinToString(" ")
            .lowercase()
        val renderer = gpu?.renderer.orEmpty().lowercase()

        val mediatek = "mt6789" in socText || "mediatek" in socText ||
            hardware.lowercase().startsWith("mt") || "mali" in renderer
        val qualcomm = "sm7435" in socText || "qualcomm" in socText || "qti" in socText ||
            hardware.equals("qcom", ignoreCase = true) || "adreno" in renderer

        val variant = when {
            mediatek && !qualcomm -> Variant.MEDIATEK_4G
            qualcomm && !mediatek -> Variant.QUALCOMM_5G
            else -> Variant.UNKNOWN
        }

        val chipName = when (variant) {
            Variant.MEDIATEK_4G ->
                if ("mt6789" in socText) "MediaTek MT6789 (Helio G99-Ultra)"
                else "MediaTek (modelo exato não confirmado)"
            Variant.QUALCOMM_5G ->
                if ("sm7435" in socText) "Qualcomm SM7435 (Snapdragon 7s Gen 2)"
                else "Qualcomm (modelo exato não confirmado)"
            Variant.UNKNOWN ->
                listOfNotNull(socManufacturer, socModel).joinToString(" ").ifBlank { hardware }
        }

        val gpuName = gpu?.renderer?.takeIf { it.isNotBlank() } ?: "GPU não identificada"

        val variantNote = when (variant) {
            Variant.MEDIATEK_4G ->
                "Chip MediaTek com GPU Mali, como no modelo 4G. Inferido pelos dados lidos aqui; outros aparelhos podem usar o mesmo chip."
            Variant.QUALCOMM_5G ->
                "Chip Qualcomm com GPU Adreno, como no modelo 5G. Inferido pelos dados lidos aqui; outros aparelhos podem usar o mesmo chip."
            Variant.UNKNOWN ->
                "Não foi possível relacionar chip e GPU a uma variante conhecida. Veja os dados brutos abaixo."
        }

        val activityManager = context.getSystemService(ActivityManager::class.java)
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memoryInfo)
        val ramTotalMb = memoryInfo.totalMem / (1024L * 1024L)

        val xiaomiFamily = listOf(Build.MANUFACTURER, Build.BRAND).any {
            it.contains("xiaomi", true) || it.contains("redmi", true) || it.contains("poco", true)
        }
        val hyperName = SystemProps.get("ro.mi.os.version.name")
        val miuiName = SystemProps.get("ro.miui.ui.version.name")
        val display = Build.DISPLAY.orEmpty()

        val (osName, osVersionRaw) = when {
            !hyperName.isNullOrBlank() -> "HyperOS" to hyperName
            xiaomiFamily && display.startsWith("OS") -> "HyperOS (inferido pela build)" to display
            !miuiName.isNullOrBlank() -> "MIUI" to miuiName
            else -> "Sem interface Xiaomi detectada" to display
        }

        val marketingName = try {
            Settings.Global.getString(context.contentResolver, "device_name")?.takeIf { it.isNotBlank() }
        } catch (t: Throwable) {
            null
        }

        return DeviceInfo(
            manufacturer = Build.MANUFACTURER.orEmpty(),
            brand = Build.BRAND.orEmpty(),
            model = Build.MODEL.orEmpty(),
            codename = Build.DEVICE.orEmpty(),
            marketingName = marketingName,
            hardware = hardware,
            board = Build.BOARD.orEmpty(),
            socManufacturer = socManufacturer,
            socModel = socModel,
            chipName = chipName,
            gpuName = gpuName,
            gpuVersion = gpu?.glVersion?.takeIf { it.isNotBlank() },
            variant = variant,
            variantNote = variantNote,
            ramTotalMb = ramTotalMb,
            androidRelease = Build.VERSION.RELEASE.orEmpty(),
            sdkInt = Build.VERSION.SDK_INT,
            securityPatch = Build.VERSION.SECURITY_PATCH?.takeIf { it.isNotBlank() },
            osName = osName,
            osVersionRaw = osVersionRaw,
            buildDisplay = display
        )
    }

    private fun String?.cleanOrNull(): String? =
        this?.trim()?.takeIf { it.isNotEmpty() && !it.equals("unknown", ignoreCase = true) }
}
