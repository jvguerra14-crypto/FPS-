package com.fpsbooster144.core.system

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager

data class SystemSnapshot(
    val thermalLevel: Int,
    val thermalLabel: String,
    val thermalHeadroom: Float?,
    val batteryTempC: Float?,
    val batteryPercent: Int?,
    val charging: Boolean,
    val powerSave: Boolean,
    val ramAvailMb: Long,
    val ramTotalMb: Long,
    val lowMemory: Boolean
)

/** Estado térmico, bateria e memória, usando apenas APIs públicas do Android. */
class SystemMonitor(private val context: Context) {

    fun read(): SystemSnapshot {
        val power = context.getSystemService(PowerManager::class.java)
        val level = power?.currentThermalStatus ?: PowerManager.THERMAL_STATUS_NONE

        // Margem térmica: 1.0 significa que a limitação de desempenho começa. Pode vir NaN.
        val headroom = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && power != null) {
            power.getThermalHeadroom(10).takeIf { !it.isNaN() }
        } else null

        val battery: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tempTenths = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val batteryTemp = if (tempTenths != null && tempTenths != Int.MIN_VALUE) tempTenths / 10f else null
        val rawLevel = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percent = if (rawLevel >= 0 && scale > 0) rawLevel * 100 / scale else null
        val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val activityManager = context.getSystemService(ActivityManager::class.java)
        val memory = ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memory)

        return SystemSnapshot(
            thermalLevel = level,
            thermalLabel = thermalLabel(level),
            thermalHeadroom = headroom,
            batteryTempC = batteryTemp,
            batteryPercent = percent,
            charging = charging,
            powerSave = power?.isPowerSaveMode ?: false,
            ramAvailMb = memory.availMem / (1024L * 1024L),
            ramTotalMb = memory.totalMem / (1024L * 1024L),
            lowMemory = memory.lowMemory
        )
    }

    private fun thermalLabel(level: Int): String = when (level) {
        PowerManager.THERMAL_STATUS_NONE -> "Normal"
        PowerManager.THERMAL_STATUS_LIGHT -> "Leve"
        PowerManager.THERMAL_STATUS_MODERATE -> "Moderado"
        PowerManager.THERMAL_STATUS_SEVERE -> "Severo"
        PowerManager.THERMAL_STATUS_CRITICAL -> "Crítico"
        PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergência"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "Desligamento"
        else -> "Desconhecido"
    }
}
