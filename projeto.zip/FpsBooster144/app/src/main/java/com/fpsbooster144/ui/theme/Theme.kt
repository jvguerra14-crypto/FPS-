package com.fpsbooster144.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AppColorScheme = darkColorScheme(
    primary = Color(0xFF6C9CFF),
    onPrimary = Color(0xFF07122B),
    secondary = Color(0xFFFFB454),
    onSecondary = Color(0xFF2A1A00),
    background = Color(0xFF0A0E1A),
    onBackground = Color(0xFFE6EAF5),
    surface = Color(0xFF121829),
    onSurface = Color(0xFFE6EAF5),
    surfaceVariant = Color(0xFF1B2339),
    onSurfaceVariant = Color(0xFF9AA6C2),
    outline = Color(0xFF2B3552)
)

object StatusColors {
    val ok = Color(0xFF58D6A0)
    val info = Color(0xFF7FB2FF)
    val warn = Color(0xFFFFB454)
    val bad = Color(0xFFFF7B86)
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AppColorScheme, content = content)
}
