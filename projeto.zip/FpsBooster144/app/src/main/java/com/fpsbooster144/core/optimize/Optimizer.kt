package com.fpsbooster144.core.optimize

import com.fpsbooster144.core.device.DeviceInfo
import com.fpsbooster144.core.display.DisplayProvider
import com.fpsbooster144.core.display.DisplayStatus
import com.fpsbooster144.core.display.RefreshMode
import com.fpsbooster144.core.system.SystemSnapshot
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

enum class ActionStatus(val label: String) {
    APPLIED("Aplicado e confirmado"),
    INFO("Informação"),
    WARNING("Atenção"),
    NOT_ALLOWED("Não foi possível alterar")
}

data class ActionResult(
    val title: String,
    val detail: String,
    val status: ActionStatus
)

/**
 * Executa as verificações e as únicas ações que um app comum, sem root, consegue fazer.
 * Cada resultado descreve o que realmente aconteceu.
 */
class Optimizer(private val displayProvider: DisplayProvider) {

    suspend fun run(
        device: DeviceInfo,
        snapshot: SystemSnapshot,
        maxFps: Boolean,
        applyMode: (RefreshMode) -> Boolean
    ): List<ActionResult> {
        val out = mutableListOf<ActionResult>()

        out += ActionResult(
            "Hardware detectado",
            "${device.chipName}. GPU: ${device.gpuName}. ${device.ramTotalMb} MB de RAM. " +
                "Android ${device.androidRelease}, ${device.osName} ${device.osVersionRaw}.",
            ActionStatus.INFO
        )

        val display = displayProvider.read()
        if (display == null) {
            out += ActionResult(
                "Taxas de atualização",
                "Não foi possível ler os modos de tela deste aparelho.",
                ActionStatus.WARNING
            )
        } else {
            val rates = display.supportedRates.joinToString(", ") { "${it.roundToInt()} Hz" }
            out += ActionResult(
                "Taxas de atualização",
                "Modos disponíveis: $rates. A tela está em ${display.currentHz.roundToInt()} Hz agora.",
                ActionStatus.INFO
            )
        }

        val headroomText = snapshot.thermalHeadroom?.let {
            " Margem térmica em ${(it * 100).roundToInt()}% do limite (100% é onde começa a limitação)."
        }.orEmpty()
        val tempText = snapshot.batteryTempC?.let {
            " Bateria a ${"%.1f".format(it)} °C."
        }.orEmpty()
        out += ActionResult(
            "Estado térmico",
            "${snapshot.thermalLabel}.$headroomText$tempText",
            if (snapshot.thermalLevel >= 3) ActionStatus.WARNING else ActionStatus.INFO
        )

        if (snapshot.powerSave) {
            out += ActionResult(
                "Economia de bateria",
                "Está ativa e pode limitar desempenho e taxa de atualização. Desative antes de jogar.",
                ActionStatus.WARNING
            )
        }

        if (display != null) {
            out += applyRefresh(display, snapshot, maxFps, applyMode)
        }

        out += ActionResult(
            "Clock de CPU e GPU",
            "O Android não permite que apps comuns alterem frequências sem root ou acesso privilegiado.",
            ActionStatus.NOT_ALLOWED
        )
        out += ActionResult(
            "Taxa de atualização dentro dos jogos",
            "Cada jogo usa a taxa do sistema (Configurações > Tela) ou a que ele próprio pede. Este app só controla a própria janela.",
            ActionStatus.NOT_ALLOWED
        )
        out += ActionResult(
            "FPS real de outros apps",
            "Medir o FPS de um jogo exige ADB ou Shizuku. Esta versão não mede; a taxa mostrada é a da tela.",
            ActionStatus.NOT_ALLOWED
        )
        out += ActionResult(
            "Liberar memória RAM",
            "Não é feito: o Android gerencia a RAM sozinho e encerrar processos tende a piorar a fluidez.",
            ActionStatus.NOT_ALLOWED
        )
        return out
    }

    private suspend fun applyRefresh(
        display: DisplayStatus,
        snapshot: SystemSnapshot,
        maxFps: Boolean,
        applyMode: (RefreshMode) -> Boolean
    ): ActionResult {
        val title = "Taxa de atualização do app"
        val target = display.bestMode
            ?: return ActionResult(title, "Nenhum modo de tela mais alto foi encontrado.", ActionStatus.INFO)
        val targetHz = target.hz.roundToInt()

        if (!maxFps && snapshot.thermalLevel >= 2) {
            return ActionResult(
                title,
                "Mantive a taxa atual porque o estado térmico está ${snapshot.thermalLabel.lowercase()}. " +
                    "O botão FPS MÁXIMO força $targetHz Hz mesmo assim.",
                ActionStatus.INFO
            )
        }
        if (display.currentHz >= target.hz - 1f) {
            return ActionResult(title, "A tela já está na taxa máxima ($targetHz Hz).", ActionStatus.INFO)
        }

        if (!applyMode(target)) {
            return ActionResult(title, "O sistema recusou o pedido de $targetHz Hz.", ActionStatus.WARNING)
        }
        delay(700)
        val after = displayProvider.read()?.currentHz
        return if (after != null && after >= target.hz - 1f) {
            ActionResult(
                title,
                "Confirmado: a tela passou para ${after.roundToInt()} Hz. Vale enquanto o app estiver aberto.",
                ActionStatus.APPLIED
            )
        } else {
            val now = after?.roundToInt()?.toString() ?: "?"
            ActionResult(
                title,
                "Pedi $targetHz Hz, mas o sistema manteve $now Hz. Isso pode depender de bateria, temperatura ou de Configurações > Tela.",
                ActionStatus.WARNING
            )
        }
    }
}
