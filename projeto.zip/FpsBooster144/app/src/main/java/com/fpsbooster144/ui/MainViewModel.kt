package com.fpsbooster144.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fpsbooster144.core.device.DeviceDetector
import com.fpsbooster144.core.device.DeviceInfo
import com.fpsbooster144.core.display.DisplayProvider
import com.fpsbooster144.core.display.DisplayStatus
import com.fpsbooster144.core.display.RefreshMode
import com.fpsbooster144.core.game.GameEntry
import com.fpsbooster144.core.game.GameLibrary
import com.fpsbooster144.core.optimize.ActionResult
import com.fpsbooster144.core.optimize.Optimizer
import com.fpsbooster144.core.system.SystemMonitor
import com.fpsbooster144.core.system.SystemSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiState(
    val loading: Boolean = true,
    val device: DeviceInfo? = null,
    val display: DisplayStatus? = null,
    val snapshot: SystemSnapshot? = null,
    val games: List<GameEntry> = emptyList(),
    val running: Boolean = false,
    val resultsTitle: String = "",
    val results: List<ActionResult> = emptyList()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val detector = DeviceDetector(context)
    private val displayProvider = DisplayProvider(context)
    private val monitor = SystemMonitor(context)
    private val library = GameLibrary(context)
    private val optimizer = Optimizer(displayProvider)

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val device = withContext(Dispatchers.Default) { detector.detect() }
            val games = withContext(Dispatchers.Default) { library.installed() }
            _state.update { it.copy(loading = false, device = device, games = games) }

            // Atualiza tela, temperatura, bateria e memória a cada 2 segundos.
            while (true) {
                val display = displayProvider.read()
                val snapshot = monitor.read()
                _state.update { it.copy(display = display, snapshot = snapshot) }
                delay(2000)
            }
        }
    }

    fun refreshGames() {
        viewModelScope.launch {
            val games = withContext(Dispatchers.Default) { library.installed() }
            _state.update { it.copy(games = games) }
        }
    }

    fun optimize(maxFps: Boolean, applyMode: (RefreshMode) -> Boolean) {
        val current = _state.value
        val device = current.device ?: return
        if (current.running) return

        viewModelScope.launch {
            _state.update {
                it.copy(
                    running = true,
                    results = emptyList(),
                    resultsTitle = if (maxFps) "Resultado do FPS máximo" else "Resultado da otimização"
                )
            }
            val results = optimizer.run(device, monitor.read(), maxFps, applyMode)
            _state.update { it.copy(running = false, results = results) }
        }
    }
}
