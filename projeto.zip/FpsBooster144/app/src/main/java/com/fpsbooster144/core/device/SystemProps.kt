package com.fpsbooster144.core.device

/**
 * Lê propriedades do sistema com o comando `getprop`, que qualquer app pode executar.
 * As propriedades específicas da Xiaomi não são documentadas oficialmente;
 * por isso o resultado é "melhor esforço" e pode vir vazio.
 */
object SystemProps {
    fun get(key: String): String? = try {
        val process = Runtime.getRuntime().exec(arrayOf("getprop", key))
        val value = process.inputStream.bufferedReader().use { it.readLine() }?.trim()
        process.destroy()
        if (value.isNullOrEmpty()) null else value
    } catch (t: Throwable) {
        null
    }
}
