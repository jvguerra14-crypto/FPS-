package com.fpsbooster144.core.display

import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display
import kotlin.math.roundToInt

data class RefreshMode(val modeId: Int, val width: Int, val height: Int, val hz: Float)

data class DisplayStatus(
    val currentHz: Float,
    val currentWidth: Int,
    val currentHeight: Int,
    val modes: List<RefreshMode>,
    val supportedRates: List<Float>,
    val maxHz: Float,
    val bestMode: RefreshMode?
)

/** Lê os modos de tela reais informados pelo sistema. */
class DisplayProvider(private val context: Context) {

    fun read(): DisplayStatus? {
        val manager = context.getSystemService(DisplayManager::class.java) ?: return null
        val display = manager.getDisplay(Display.DEFAULT_DISPLAY) ?: return null
        val current = display.mode

        val modes = display.supportedModes.map {
            RefreshMode(it.modeId, it.physicalWidth, it.physicalHeight, it.refreshRate)
        }
        // Só comparamos modos com a mesma resolução da tela atual.
        val sameResolution = modes.filter {
            it.width == current.physicalWidth && it.height == current.physicalHeight
        }
        val usable = sameResolution.ifEmpty { modes }
        val rates = usable.map { it.hz.roundToInt().toFloat() }.distinct().sorted()
        val best = usable.maxByOrNull { it.hz }

        return DisplayStatus(
            currentHz = display.refreshRate,
            currentWidth = current.physicalWidth,
            currentHeight = current.physicalHeight,
            modes = modes,
            supportedRates = rates,
            maxHz = best?.hz ?: display.refreshRate,
            bestMode = best
        )
    }
}
