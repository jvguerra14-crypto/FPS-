package com.fpsbooster144.core.game

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo

data class GameEntry(
    val packageName: String,
    val label: String,
    val isPriority: Boolean
)

/** Encontra os jogos instalados. Perfis e histórico por jogo chegam na etapa 3. */
class GameLibrary(private val context: Context) {

    private val knownGames = linkedMapOf(
        "com.dts.freefireth" to "Free Fire",
        "com.dts.freefiremax" to "Free Fire MAX",
        "com.tencent.ig" to "PUBG Mobile",
        "com.activision.callofduty.shooter" to "Call of Duty Mobile",
        "com.mojang.minecraftpe" to "Minecraft"
    )

    @Suppress("DEPRECATION")
    fun installed(): List<GameEntry> {
        val packageManager = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = LinkedHashMap<String, GameEntry>()

        for (info in packageManager.queryIntentActivities(launcherIntent, 0)) {
            val packageName = info.activityInfo.packageName
            val knownName = knownGames[packageName]
            val markedAsGame = info.activityInfo.applicationInfo.category == ApplicationInfo.CATEGORY_GAME
            if (knownName == null && !markedAsGame) continue

            val label = knownName ?: info.loadLabel(packageManager).toString()
            found[packageName] = GameEntry(packageName, label, knownName != null)
        }

        return found.values.sortedWith(
            compareByDescending<GameEntry> { it.isPriority }.thenBy { it.label.lowercase() }
        )
    }
}
